


class hypSyntaxError(Exception):
    pass


class hypFileError(Exception):
    pass


class hypObjectError(Exception):
    pass