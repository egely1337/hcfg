const express = require('express')
const app = express()
const http = require('http')
const server = http.createServer(app)



var ipList = []

app.get('/', function(req,res){
    ipList.push(req.ip);
    console.log(req.ip)
    res.send({status : 'Ok'})
})



app.post('/post/',function(req,res){
    res.send({data : req.body})
});


server.listen(3000)