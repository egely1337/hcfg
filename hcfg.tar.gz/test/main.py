from os import name
from hcfg import *


if __name__ == "__main__":
    object = {
        "hyper" : "hyper",
        "int" : 123
    }

    print(hcfg.readFile("hyper.hcfg"))