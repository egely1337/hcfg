from requests import *
from random import *



if __name__ == "__main__":
    request = post("localhost:3000/post",data={"data" : "Hi"})
    