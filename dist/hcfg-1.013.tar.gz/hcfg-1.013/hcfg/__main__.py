from hcfg import hcfg

if __name__ == "__main__":
    parser1 = hcfg()
    parser1.readFile("test.hcfg")

